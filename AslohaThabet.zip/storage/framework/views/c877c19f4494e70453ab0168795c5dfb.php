

<?php $__env->startSection('title', 'إنشاء امتحان'); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-header">
        <h1>إنشاء امتحان جديد</h1>
        <a href="<?php echo e(route('exams.index', ['level_id' => $levelId])); ?>" class="btn btn-outline">⟵ رجوع للقائمة</a>
    </div>

    <div class="card" style="max-width: 560px;">
        <form method="POST" action="<?php echo e(route('exams.store')); ?>">
            <?php echo csrf_field(); ?>

            <div class="form-group">
                <label for="level_id">المستوى</label>
                <select name="level_id" id="level_id" required>
                    <?php $__currentLoopData = $levels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $level): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($level->id); ?>" <?php echo e(old('level_id', $levelId) == $level->id ? 'selected' : ''); ?>>
                            <?php echo e($level->name); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <div class="form-group">
                <label for="title">عنوان الامتحان</label>
                <input type="text" name="title" id="title" required value="<?php echo e(old('title')); ?>">
            </div>

            <div class="form-group">
                <label for="description">الوصف (اختياري)</label>
                <textarea name="description" id="description" rows="2"><?php echo e(old('description')); ?></textarea>
            </div>

            <div style="display:grid; grid-template-columns:1fr 1fr; gap:12px;">
                <div class="form-group">
                    <label for="start_at">يبدأ في</label>
                    <input type="datetime-local" name="start_at" id="start_at" required value="<?php echo e(old('start_at')); ?>">
                </div>
                <div class="form-group">
                    <label for="end_at">ينتهي في</label>
                    <input type="datetime-local" name="end_at" id="end_at" required value="<?php echo e(old('end_at')); ?>">
                </div>
            </div>

            <div class="form-group">
                <label for="duration_minutes">مدة الامتحان (بالدقائق)</label>
                <input type="number" name="duration_minutes" id="duration_minutes" min="1" max="600" required
                       value="<?php echo e(old('duration_minutes', 30)); ?>">
                <small style="color: var(--color-muted);">
                    لو الطالب دخل الامتحان متأخراً، الوقت المتاح هو الأقل بين هذه المدة ووقت نهاية الامتحان.
                </small>
            </div>

            <button type="submit" class="btn btn-primary" style="width:100%;">إنشاء الامتحان</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.academy', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\work\Laravel\AslohaThabet\resources\views/exams/create.blade.php ENDPATH**/ ?>