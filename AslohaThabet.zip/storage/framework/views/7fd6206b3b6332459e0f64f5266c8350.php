

<?php $__env->startSection('title', 'التقييم الأسبوعي'); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-header">
        <h1>التقييم الأسبوعي — اختر الفصل والأسبوع</h1>
    </div>

    <div class="card">
        <?php $__empty_1 = true; $__currentLoopData = $classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $class): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <?php
                $weeksForThisLevel = $publishedPlansByLevel->get($class->level_id, collect());
            ?>
            <div style="border-bottom: 1px solid var(--color-border); padding: 16px 0;">
                <div style="display:flex; align-items:center; justify-content:space-between; margin-bottom: 10px;">
                    <div>
                        <strong><?php echo e($class->name); ?></strong>
                        <span style="color: var(--color-muted); font-size: 13px;"> — <?php echo e($class->level->name); ?></span>
                        <?php if($class->activeTeacherAssignment): ?>
                            <span style="color: var(--color-muted); font-size: 13px;">
                                (المعلم/ة: <?php echo e($class->activeTeacherAssignment->teacher->full_name); ?>)
                            </span>
                        <?php endif; ?>
                    </div>
                </div>

                <?php if($weeksForThisLevel->isEmpty()): ?>
                    <p style="color: var(--color-muted); font-size: 13px;">لا توجد أسابيع منشورة لهذا المستوى بعد.</p>
                <?php else: ?>
                    <div style="display:flex; gap:8px; flex-wrap: wrap;">
                        <?php $__currentLoopData = $weeksForThisLevel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a href="<?php echo e(route('weekly-evaluations.grade', ['class_id' => $class->id, 'weekly_plan_id' => $plan->id])); ?>"
                               class="btn btn-outline">
                                الأسبوع <?php echo e($plan->week_number); ?>: <?php echo e($plan->title); ?>

                            </a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                <?php endif; ?>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <p style="text-align:center; color: var(--color-muted); padding: 30px;">
                لا توجد فصول متاحة لك للتصحيح حالياً.
            </p>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.academy', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\work\Laravel\AslohaThabet\resources\views/weekly-evaluations/index.blade.php ENDPATH**/ ?>