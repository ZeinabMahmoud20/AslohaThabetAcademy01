

<?php $__env->startSection('title', 'الامتحانات'); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-header">
        <h1>الامتحانات</h1>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create', \App\Models\Exam::class)): ?>
            <a href="<?php echo e(route('exams.create', ['level_id' => $levelId])); ?>" class="btn btn-primary">+ امتحان جديد</a>
        <?php endif; ?>
    </div>

    <div class="card" style="margin-bottom: 18px; display:flex; gap:10px; flex-wrap: wrap;">
        <?php $__currentLoopData = $levels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $level): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a href="<?php echo e(route('exams.index', ['level_id' => $level->id])); ?>"
               class="btn <?php echo e($levelId == $level->id ? 'btn-gold' : 'btn-outline'); ?>"><?php echo e($level->name); ?></a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <div class="card">
        <table>
            <thead>
                <tr>
                    <th>العنوان</th>
                    <th>يبدأ</th>
                    <th>ينتهي</th>
                    <th>عدد الأسئلة</th>
                    <th>الدرجة الكلية</th>
                    <th>المحاولات</th>
                    <th>الحالة</th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $exams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exam): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($exam->title); ?></td>
                        <td><?php echo e($exam->start_at->format('Y-m-d H:i')); ?></td>
                        <td><?php echo e($exam->end_at->format('Y-m-d H:i')); ?></td>
                        <td><?php echo e($exam->questions_count); ?></td>
                        <td><?php echo e($exam->max_score); ?></td>
                        <td><?php echo e($exam->attempts_count); ?></td>
                        <td>
                            <?php
                                $statusMap = [
                                    'draft' => ['مسودة', 'badge-pending'],
                                    'reviewed' => ['تمت المراجعة', 'badge-pending'],
                                    'published' => ['منشور', 'badge-accepted'],
                                    'closed' => ['مغلق', 'badge-rejected'],
                                ];
                                [$label, $class] = $statusMap[$exam->status] ?? [$exam->status, 'badge-pending'];
                            ?>
                            <span class="badge-status <?php echo e($class); ?>"><?php echo e($label); ?></span>
                        </td>
                        <td style="display:flex; gap:6px;">
                            <a href="<?php echo e(route('exams.show', $exam)); ?>" class="btn btn-outline">
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update', $exam)): ?> إدارة <?php else: ?> عرض <?php endif; ?>
                            </a>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view', $exam)): ?>
                                <?php if($exam->attempts_count > 0): ?>
                                    <a href="<?php echo e(route('exams.results', $exam)); ?>" class="btn btn-outline">النتائج</a>
                                <?php endif; ?>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="8" style="text-align:center; color: var(--color-muted); padding: 30px;">
                            لا توجد امتحانات لهذا المستوى بعد.
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.academy', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\work\Laravel\AslohaThabet\resources\views/exams/index.blade.php ENDPATH**/ ?>