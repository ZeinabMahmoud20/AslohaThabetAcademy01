

<?php $__env->startSection('title', 'لوحة المعلومات'); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-header">
        <h1>مرحباً، <?php echo e(auth()->user()->full_name); ?> 👋</h1>
    </div>

    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(180px, 1fr)); gap: 16px; margin-bottom: 24px;">

        <a href="<?php echo e(route('applications.index', ['status' => 'pending_review'])); ?>" class="card" style="text-decoration:none; display:block;">
            <div style="font-size: 28px; font-weight: 800; color: var(--color-green-dark);"><?php echo e($stats['pending_applications']); ?></div>
            <div style="font-size: 13px; color: var(--color-muted); margin-top: 4px;">📝 طلبات قيد المراجعة</div>
        </a>

        <a href="<?php echo e(route('students.index', ['status' => 'unassigned'])); ?>" class="card" style="text-decoration:none; display:block;">
            <div style="font-size: 28px; font-weight: 800; color: var(--color-green-dark);"><?php echo e($stats['unassigned_students']); ?></div>
            <div style="font-size: 13px; color: var(--color-muted); margin-top: 4px;">🎓 طلاب بدون فصل</div>
        </a>

        <a href="<?php echo e(route('students.index')); ?>" class="card" style="text-decoration:none; display:block;">
            <div style="font-size: 28px; font-weight: 800; color: var(--color-green-dark);"><?php echo e($stats['active_students']); ?></div>
            <div style="font-size: 13px; color: var(--color-muted); margin-top: 4px;">👦 إجمالي الطلاب النشطين</div>
        </a>

        <a href="<?php echo e(route('classes.index')); ?>" class="card" style="text-decoration:none; display:block;">
            <div style="font-size: 28px; font-weight: 800; color: var(--color-green-dark);"><?php echo e($stats['active_classes']); ?></div>
            <div style="font-size: 13px; color: var(--color-muted); margin-top: 4px;">🏫 الفصول النشطة</div>
        </a>

        <a href="<?php echo e(route('staff.index', ['role' => 'all'])); ?>" class="card" style="text-decoration:none; display:block;">
            <div style="font-size: 28px; font-weight: 800; color: var(--color-green-dark);"><?php echo e($stats['staff_count']); ?></div>
            <div style="font-size: 13px; color: var(--color-muted); margin-top: 4px;">👩‍🏫 المعلمات والمشرفات</div>
        </a>

        <a href="<?php echo e(route('exams.index')); ?>" class="card" style="text-decoration:none; display:block;">
            <div style="font-size: 28px; font-weight: 800; color: var(--color-green-dark);"><?php echo e($stats['published_exams']); ?></div>
            <div style="font-size: 13px; color: var(--color-muted); margin-top: 4px;">📋 امتحانات منشورة حالياً</div>
        </a>
    </div>

    <div class="card">
        <div style="display:flex; align-items:center; justify-content:space-between; margin-bottom: 14px;">
            <h3 style="color: var(--color-green-dark); margin:0;">أحدث طلبات الالتحاق المعلّقة</h3>
            <a href="<?php echo e(route('applications.index')); ?>" class="btn btn-outline">عرض الكل</a>
        </div>

        <table>
            <thead>
                <tr>
                    <th>اسم الطالب/ة</th>
                    <th>ولي الأمر</th>
                    <th>تاريخ التقديم</th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $recentApplications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $application): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($application->student_full_name); ?></td>
                        <td><?php echo e($application->guardian->full_name); ?></td>
                        <td><?php echo e($application->submitted_at->format('Y-m-d')); ?></td>
                        <td>
                            <a href="<?php echo e(route('applications.show', $application)); ?>" class="btn btn-outline">مراجعة</a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="4" style="text-align:center; color: var(--color-muted); padding: 24px;">
                            لا توجد طلبات معلّقة حالياً 🎉
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.academy', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\work\Laravel\AslohaThabet\resources\views/dashboard-admin.blade.php ENDPATH**/ ?>