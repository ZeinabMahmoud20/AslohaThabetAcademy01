

<?php $__env->startSection('title', 'نتائج امتحان — ' . $exam->title); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-header">
        <h1>نتائج: <?php echo e($exam->title); ?></h1>
        <a href="<?php echo e(route('exams.show', $exam)); ?>" class="btn btn-outline">⟵ رجوع لإدارة الامتحان</a>
    </div>

    <div class="card">
        <table>
            <thead>
                <tr>
                    <th>الطالب/ة</th>
                    <th>الدرجة</th>
                    <th>النسبة</th>
                    <th>وقت التسليم</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $attempts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attempt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($attempt->levelAttempt->student->full_name); ?></td>
                        <td><?php echo e($attempt->score); ?> / <?php echo e($exam->max_score); ?></td>
                        <td>
                            <span class="badge-status <?php echo e($attempt->percentage >= 50 ? 'badge-accepted' : 'badge-rejected'); ?>">
                                <?php echo e($attempt->percentage); ?>%
                            </span>
                        </td>
                        <td><?php echo e($attempt->submitted_at?->format('Y-m-d H:i')); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="4" style="text-align:center; color: var(--color-muted); padding: 30px;">
                            لا توجد محاولات مصححة بعد.
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.academy', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\work\Laravel\AslohaThabet\resources\views/exams/results.blade.php ENDPATH**/ ?>