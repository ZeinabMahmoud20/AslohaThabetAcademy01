<?php $__env->startSection('title', 'طلبات الالتحاق'); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-header">
        <h1>طلبات الالتحاق</h1>
    </div>

    <div class="card" style="margin-bottom: 18px; display:flex; gap:10px;">
        <a href="<?php echo e(route('applications.index')); ?>"
           class="btn <?php echo e(request('status') ? 'btn-outline' : 'btn-gold'); ?>">الكل</a>
        <a href="<?php echo e(route('applications.index', ['status' => 'pending_review'])); ?>"
           class="btn <?php echo e(request('status') === 'pending_review' ? 'btn-gold' : 'btn-outline'); ?>">قيد المراجعة</a>
        <a href="<?php echo e(route('applications.index', ['status' => 'accepted'])); ?>"
           class="btn <?php echo e(request('status') === 'accepted' ? 'btn-gold' : 'btn-outline'); ?>">مقبول</a>
        <a href="<?php echo e(route('applications.index', ['status' => 'rejected'])); ?>"
           class="btn <?php echo e(request('status') === 'rejected' ? 'btn-gold' : 'btn-outline'); ?>">مرفوض</a>
    </div>

    <div class="card">
        <table>
            <thead>
                <tr>
                    <th>اسم الطالب</th>
                    <th>ولي الأمر</th>
                    <th>العمر</th>
                    <th>تاريخ التقديم</th>
                    <th>الحالة</th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $applications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $application): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td>
                            <?php echo e($application->student_full_name); ?>

                            <?php if($application->is_age_exception): ?>
                                <span class="badge-status badge-pending" title="استثناء عمر">⚠️ استثناء</span>
                            <?php endif; ?>
                        </td>
                        <td><?php echo e($application->guardian->full_name); ?></td>
                        <td><?php echo e($application->computed_age_years); ?> سنة</td>
                        <td><?php echo e($application->submitted_at->format('Y-m-d')); ?></td>
                        <td>
                            <?php
                                $statusMap = [
                                    'pending_review' => ['قيد المراجعة', 'badge-pending'],
                                    'admin_review' => ['مراجعة إدارية', 'badge-pending'],
                                    'accepted' => ['مقبول', 'badge-accepted'],
                                    'rejected' => ['مرفوض', 'badge-rejected'],
                                ];
                                [$label, $class] = $statusMap[$application->status] ?? [$application->status, 'badge-pending'];
                            ?>
                            <span class="badge-status <?php echo e($class); ?>"><?php echo e($label); ?></span>
                        </td>
                        <td>
                            <a href="<?php echo e(route('applications.show', $application)); ?>" class="btn btn-outline">مراجعة</a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="6" style="text-align:center; color: var(--color-muted); padding: 30px;">
                            لا توجد طلبات مطابقة.
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <div style="margin-top: 18px;">
        <?php echo e($applications->links()); ?>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.academy', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\work\Laravel\AslohaThabet\resources\views/applications/index.blade.php ENDPATH**/ ?>