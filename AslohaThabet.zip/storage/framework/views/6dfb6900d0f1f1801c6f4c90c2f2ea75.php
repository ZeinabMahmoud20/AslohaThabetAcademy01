

<?php $__env->startSection('title', 'إدارة الخطة الأسبوعية — ' . $weeklyPlan->title); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-header">
        <h1>الأسبوع <?php echo e($weeklyPlan->week_number); ?>: <?php echo e($weeklyPlan->title); ?></h1>
        <a href="<?php echo e(route('weekly-plans.index', ['level_id' => $weeklyPlan->level_id])); ?>" class="btn btn-outline">⟵ رجوع للقائمة</a>
    </div>

    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update', $weeklyPlan)): ?>
        <?php if($weeklyPlan->status === 'draft'): ?>
            <div class="alert alert-error" style="display:flex; align-items:center; justify-content:space-between;">
                <span>هذه الخطة لا تزال مسودة ولن تظهر للمعلمين حتى يتم نشرها.</span>
                <form method="POST" action="<?php echo e(route('weekly-plans.publish', $weeklyPlan)); ?>">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PATCH'); ?>
                    <button type="submit" class="btn btn-gold">نشر الخطة الآن</button>
                </form>
            </div>
        <?php else: ?>
            <div class="alert alert-success">هذه الخطة منشورة ومتاحة للمعلمين.</div>
        <?php endif; ?>
    <?php else: ?>
        <?php if($weeklyPlan->status === 'draft'): ?>
            <div class="alert alert-error">هذه الخطة لا تزال مسودة.</div>
        <?php else: ?>
            <div class="alert alert-success">هذه الخطة منشورة ومتاحة للمعلمين.</div>
        <?php endif; ?>
    <?php endif; ?>

    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-bottom: 20px;">

        
        <div class="card">
            <h3 style="color: var(--color-green-dark); margin-top:0;">🎬 الفيديو</h3>

            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update', $weeklyPlan)): ?>
                <form method="POST" action="<?php echo e(route('weekly-plans.video.save', $weeklyPlan)); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label for="video_title">العنوان</label>
                        <input type="text" name="title" id="video_title" required
                               value="<?php echo e(old('title', $weeklyPlan->video?->title)); ?>">
                    </div>
                    <div class="form-group">
                        <label for="video_url">رابط الفيديو</label>
                        <input type="url" name="video_url" id="video_url" dir="ltr"
                               value="<?php echo e(old('video_url', $weeklyPlan->video?->video_url)); ?>"
                               placeholder="https://...">
                    </div>
                    <div class="form-group">
                        <label for="video_description">وصف (اختياري)</label>
                        <textarea name="description" id="video_description" rows="2"><?php echo e(old('description', $weeklyPlan->video?->description)); ?></textarea>
                    </div>
                    <button type="submit" class="btn btn-primary" style="width:100%;">
                        <?php echo e($weeklyPlan->video ? 'تحديث الفيديو' : 'حفظ الفيديو'); ?>

                    </button>
                </form>
            <?php else: ?>
                <?php if($weeklyPlan->video): ?>
                    <p><strong><?php echo e($weeklyPlan->video->title); ?></strong></p>
                    <?php if($weeklyPlan->video->description): ?>
                        <p style="font-size: 13px; color: var(--color-muted);"><?php echo e($weeklyPlan->video->description); ?></p>
                    <?php endif; ?>
                    <?php if($weeklyPlan->video->video_url): ?>
                        <a href="<?php echo e($weeklyPlan->video->video_url); ?>" target="_blank" class="btn btn-outline">فتح الفيديو</a>
                    <?php endif; ?>
                <?php else: ?>
                    <p style="color: var(--color-muted);">لم تتم إضافة فيديو لهذا الأسبوع بعد.</p>
                <?php endif; ?>
            <?php endif; ?>
        </div>

        
        <div class="card">
            <h3 style="color: var(--color-green-dark); margin-top:0;">📝 الواجب</h3>

            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update', $weeklyPlan)): ?>
                <form method="POST" action="<?php echo e(route('weekly-plans.homework.save', $weeklyPlan)); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label for="hw_title">العنوان</label>
                        <input type="text" name="title" id="hw_title" required
                               value="<?php echo e(old('title', $weeklyPlan->homework?->title)); ?>">
                    </div>
                    <div class="form-group">
                        <label for="hw_instructions">التعليمات</label>
                        <textarea name="instructions" id="hw_instructions" rows="3"><?php echo e(old('instructions', $weeklyPlan->homework?->instructions)); ?></textarea>
                    </div>
                    <div class="form-group">
                        <label for="due_date">تاريخ التسليم (اختياري)</label>
                        <input type="date" name="due_date" id="due_date"
                               value="<?php echo e(old('due_date', $weeklyPlan->homework?->due_date?->format('Y-m-d'))); ?>">
                    </div>
                    <button type="submit" class="btn btn-primary" style="width:100%;">
                        <?php echo e($weeklyPlan->homework ? 'تحديث الواجب' : 'حفظ الواجب'); ?>

                    </button>
                </form>
            <?php else: ?>
                <?php if($weeklyPlan->homework): ?>
                    <p><strong><?php echo e($weeklyPlan->homework->title); ?></strong></p>
                    <?php if($weeklyPlan->homework->instructions): ?>
                        <p style="font-size: 13px; color: var(--color-muted);"><?php echo e($weeklyPlan->homework->instructions); ?></p>
                    <?php endif; ?>
                    <?php if($weeklyPlan->homework->due_date): ?>
                        <p style="font-size: 12px; color: var(--color-muted);">تاريخ التسليم: <?php echo e($weeklyPlan->homework->due_date->format('Y-m-d')); ?></p>
                    <?php endif; ?>
                <?php else: ?>
                    <p style="color: var(--color-muted);">لم تتم إضافة واجب لهذا الأسبوع بعد.</p>
                <?php endif; ?>
            <?php endif; ?>
        </div>
    </div>

    
    <div class="card">
        <h3 style="color: var(--color-green-dark); margin-top:0;">📊 عناصر التقييم لهذا الأسبوع</h3>
        <p style="color: var(--color-muted); font-size: 13px; margin-top:-6px;">
            هذه العناصر ودرجاتها القصوى خاصة بهذا الأسبوع فقط — كل أسبوع يمكن أن يختلف عن غيره.
        </p>

        <table style="margin-bottom: 18px;">
            <thead>
                <tr>
                    <th>العنصر</th>
                    <th>الدرجة القصوى</th>
                    <th>إجباري؟</th>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update', $weeklyPlan)): ?>
                        <th></th>
                    <?php endif; ?>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $weeklyPlan->evaluationItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($item->evaluationItem->name); ?></td>
                        <td><?php echo e($item->max_score); ?></td>
                        <td><?php echo e($item->is_required ? 'نعم' : 'لا'); ?></td>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update', $weeklyPlan)): ?>
                            <td>
                                <?php if($weeklyPlan->status === 'draft'): ?>
                                    <form method="POST" action="<?php echo e(route('weekly-plans.evaluation-items.remove', [$weeklyPlan, $item])); ?>">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-danger" style="padding: 5px 12px; font-size:12px;">حذف</button>
                                    </form>
                                <?php endif; ?>
                            </td>
                        <?php endif; ?>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="4" style="text-align:center; color: var(--color-muted); padding: 20px;">
                            لم تتم إضافة أي عناصر تقييم بعد.
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>

        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update', $weeklyPlan)): ?>
            <?php if($weeklyPlan->status === 'draft' && $availableItems->isNotEmpty()): ?>
                <form method="POST" action="<?php echo e(route('weekly-plans.evaluation-items.add', $weeklyPlan)); ?>"
                      style="display:flex; gap:10px; align-items:flex-end; flex-wrap: wrap;">
                    <?php echo csrf_field(); ?>
                    <div class="form-group" style="margin-bottom:0;">
                        <label for="evaluation_item_id">إضافة عنصر</label>
                        <select name="evaluation_item_id" id="evaluation_item_id" required>
                            <?php $__currentLoopData = $availableItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="form-group" style="margin-bottom:0;">
                        <label for="max_score">الدرجة القصوى</label>
                        <input type="number" step="0.01" min="0.01" name="max_score" id="max_score" required
                               style="width: 100px;" placeholder="10">
                    </div>
                    <div class="form-group" style="margin-bottom:0;">
                        <label for="is_required">إجباري؟</label>
                        <select name="is_required" id="is_required">
                            <option value="1">نعم</option>
                            <option value="0">لا</option>
                        </select>
                    </div>
                    <button type="submit" class="btn btn-primary">إضافة</button>
                </form>
            <?php elseif($weeklyPlan->status !== 'draft'): ?>
                <p style="color: var(--color-muted); font-size: 13px;">لا يمكن تعديل العناصر بعد نشر الخطة.</p>
            <?php endif; ?>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.academy', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\work\Laravel\AslohaThabet\resources\views/weekly-plans/show.blade.php ENDPATH**/ ?>