

<?php $__env->startSection('title', 'إدارة الفصل — ' . $class->name); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-header">
        <h1><?php echo e($class->name); ?> — <?php echo e($class->level->name); ?></h1>
        <a href="<?php echo e(route('classes.index')); ?>" class="btn btn-outline">⟵ رجوع لكل الفصول</a>
    </div>

    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-bottom: 20px;">

        
        <div class="card">
            <h3 style="color: var(--color-green-dark); margin-top:0;">المعلم/ة الحالي/ة</h3>

            <?php if($class->activeTeacherAssignment): ?>
                <div class="alert alert-success" style="margin-bottom: 16px;">
                    <?php echo e($class->activeTeacherAssignment->teacher->full_name); ?>

                    <br><small>معيّن/ة منذ <?php echo e($class->activeTeacherAssignment->start_date->format('Y-m-d')); ?></small>
                </div>
            <?php else: ?>
                <div class="alert alert-error" style="margin-bottom: 16px;">لا يوجد معلم/ة معيّن/ة حالياً.</div>
            <?php endif; ?>
<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update', $class)): ?>
            <form method="POST" action="<?php echo e(route('classes.assign-teacher', $class)); ?>">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <label for="teacher_id">
                        <?php echo e($class->activeTeacherAssignment ? 'تبديل المعلم/ة' : 'تعيين معلم/ة'); ?>

                    </label>
                    <select name="teacher_id" id="teacher_id" required>
                        <option value="" disabled selected>اختر معلم/ة</option>
                        <?php $__currentLoopData = $availableTeachers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $teacher): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($teacher->id); ?>"><?php echo e($teacher->full_name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="form-group">
                    <label for="reason">سبب التبديل (اختياري)</label>
                    <textarea name="reason" id="reason" rows="2"></textarea>
                </div>
                <button type="submit" class="btn btn-primary" style="width:100%;">
                    <?php echo e($class->activeTeacherAssignment ? 'تبديل المعلم/ة' : 'تعيين'); ?>

                </button>
            </form>
            <?php endif; ?>

            <?php if($class->teacherAssignments->count() > 1): ?>
                <h4 style="color: var(--color-green-dark); margin-top: 20px; font-size: 14px;">سجل المعلمين السابقين</h4>
                <table>
                    <tbody>
                        <?php $__currentLoopData = $class->teacherAssignments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if(! $ta->is_active): ?>
                                <tr>
                                    <td><?php echo e($ta->teacher->full_name); ?></td>
                                    <td style="font-size: 12px; color: var(--color-muted);">
                                        <?php echo e($ta->start_date->format('Y-m-d')); ?> → <?php echo e($ta->end_date?->format('Y-m-d')); ?>

                                    </td>
                                </tr>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </div>

        
        <div class="card">
            <h3 style="color: var(--color-green-dark); margin-top:0;">المشرفون النشطون</h3>

            <?php $__empty_1 = true; $__currentLoopData = $class->activeSupervisorAssignments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div style="display:flex; align-items:center; justify-content:space-between; padding: 8px 0; border-bottom: 1px solid var(--color-border);">
                    <span><?php echo e($sa->supervisor->full_name); ?></span>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update', $class)): ?>
                    <form method="POST" action="<?php echo e(route('classes.supervisors.end', [$class, $sa->id])); ?>">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PATCH'); ?>
                        <button type="submit" class="btn btn-danger" style="padding: 5px 12px; font-size:12px;">إنهاء</button>
                    </form>
                    <?php endif; ?>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="alert alert-error" style="margin-bottom: 16px;">لا يوجد مشرفون معيّنون حالياً.</div>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update', $class)): ?>
            <form method="POST" action="<?php echo e(route('classes.assign-supervisor', $class)); ?>" style="margin-top: 16px;">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <label for="supervisor_id">إضافة مشرف/ة</label>
                    <select name="supervisor_id" id="supervisor_id" required>
                        <option value="" disabled selected>اختر مشرف/ة</option>
                        <?php $__currentLoopData = $availableSupervisors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $supervisor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($supervisor->id); ?>"><?php echo e($supervisor->full_name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <button type="submit" class="btn btn-primary" style="width:100%;">إضافة</button>
            </form>
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.academy', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\work\Laravel\AslohaThabet\resources\views/classes/show.blade.php ENDPATH**/ ?>