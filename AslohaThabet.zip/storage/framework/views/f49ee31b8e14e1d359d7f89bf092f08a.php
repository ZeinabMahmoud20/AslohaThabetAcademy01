<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo e($student->full_name); ?> — بوابة أولياء الأمور</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700;800&display=swap" rel="stylesheet">
    <style>
        :root {
            --color-gold: #F1C40F;
            --color-gold-dark: #d4ac0d;
            --color-green: #1E8449;
            --color-green-dark: #166638;
            --color-white: #FFFFFF;
            --color-border: #e7e2d0;
            --color-bg: #f7f6f1;
        }
        * { box-sizing: border-box; }
        body { margin: 0; font-family: 'Cairo', system-ui, sans-serif; background: var(--color-bg); }
        a { text-decoration: none; color: inherit; }
        .topbar {
            background: linear-gradient(180deg, var(--color-gold) 0%, var(--color-gold-dark) 100%);
            color: var(--color-green-dark);
            padding: 14px 24px;
            display: flex; align-items: center; justify-content: space-between;
        }
        .topbar .back { font-weight: 700; font-size: 13px; }
        .content { max-width: 720px; margin: 0 auto; padding: 24px 20px; }
        .header-card {
            background: var(--color-green); color: var(--color-white);
            border-radius: 14px; padding: 20px; margin-bottom: 20px;
        }
        .header-card h2 { margin: 0 0 4px; font-size: 20px; }
        .header-card .meta { font-size: 13px; opacity: 0.85; }

        .final-result-card {
            background: var(--color-white); border: 2px solid var(--color-gold);
            border-radius: 14px; padding: 18px 20px; margin-bottom: 20px; text-align: center;
        }
        .final-result-card .score { font-size: 32px; font-weight: 800; color: var(--color-green-dark); }
        .final-result-card .grade { font-size: 15px; font-weight: 700; margin-top: 4px; }

        .week-card {
            background: var(--color-white); border: 1px solid var(--color-border);
            border-radius: 14px; padding: 18px 20px; margin-bottom: 14px;
            box-shadow: 0 2px 8px rgba(30,132,73,0.06);
        }
        .week-card .week-title {
            display:flex; align-items:center; justify-content:space-between;
            font-weight: 800; color: var(--color-green-dark); font-size: 15px; margin-bottom: 10px;
        }
        .week-score { background: #eef7f0; color: var(--color-green-dark); padding: 3px 12px; border-radius: 14px; font-size: 13px; font-weight: 700; }
        .item-row { display:flex; justify-content:space-between; padding: 6px 0; border-bottom: 1px dashed var(--color-border); font-size: 13px; }
        .item-row:last-of-type { border-bottom: none; }
        .resource-links { margin-top: 12px; display:flex; gap: 10px; flex-wrap: wrap; }
        .resource-links a {
            background: var(--color-gold); color: var(--color-green-dark);
            padding: 6px 14px; border-radius: 8px; font-size: 12px; font-weight: 700;
        }
        .empty { text-align:center; color: #999; padding: 40px 0; }
    </style>
</head>
<body>
    <header class="topbar">
        <a href="<?php echo e(route('portal.dashboard')); ?>" class="back">⟵ رجوع لكل الأبناء</a>
        <span>📖 <?php echo e($student->full_name); ?></span>
    </header>

    <div class="content">
        <div class="header-card">
            <h2><?php echo e($student->full_name); ?></h2>
            <div class="meta">
                <?php if($activeAttempt): ?>
                    <?php echo e($activeAttempt->level->name); ?>

                <?php else: ?>
                    لا يوجد مستوى نشط حالياً
                <?php endif; ?>
            </div>
        </div>

        <?php if($finalResult): ?>
            <div class="final-result-card">
                <div class="score"><?php echo e($finalResult->final_score); ?> / 100</div>
                <div class="grade"><?php echo e($finalResult->grade_label); ?> — <?php echo e($finalResult->pass_fail === 'passed' ? 'ناجح/ة' : 'يحتاج إعادة'); ?></div>
            </div>
        <?php endif; ?>

        <h3 style="color: var(--color-green-dark); margin-bottom: 12px;">الامتحانات المتاحة</h3>

<?php $__empty_1 = true; $__currentLoopData = $availableExams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exam): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <?php $examAttempt = $examAttemptsByExamId->get($exam->id); ?>
    <div class="week-card" style="display:flex; align-items:center; justify-content:space-between;">
        <div>
            <strong style="color: var(--color-green-dark);"><?php echo e($exam->title); ?></strong>
            <div style="font-size: 12px; color: #6b7a72; margin-top: 4px;">
                متاح حتى <?php echo e($exam->end_at->format('Y-m-d H:i')); ?> — المدة <?php echo e($exam->duration_minutes); ?> دقيقة
            </div>
        </div>

        <?php if(! $examAttempt || $examAttempt->status === 'not_started'): ?>
            <form method="POST" action="<?php echo e(route('portal.exams.start', [$student, $exam])); ?>">
                <?php echo csrf_field(); ?>
                <button type="submit" class="btn-view" style="border:none; cursor:pointer; font-family:inherit;">ابدأ الامتحان</button>
            </form>
        <?php elseif($examAttempt->status === 'in_progress'): ?>
            <a href="<?php echo e(route('portal.exams.take', [$student, $exam])); ?>" class="btn-view">متابعة الامتحان</a>
        <?php else: ?>
            <a href="<?php echo e(route('portal.exams.result', [$student, $exam])); ?>" class="week-score" style="text-decoration:none;">
                <?php echo e($examAttempt->score); ?> / <?php echo e($exam->max_score); ?>

            </a>
        <?php endif; ?>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <p class="empty" style="padding: 16px 0;">لا توجد امتحانات متاحة حالياً.</p>
<?php endif; ?>

        <h3 style="color: var(--color-green-dark); margin-bottom: 12px;">الأسابيع والدرجات</h3>

        <?php $__empty_1 = true; $__currentLoopData = $weeklyEvaluations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $evaluation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="week-card">
                <div class="week-title">
                    <span>الأسبوع <?php echo e($evaluation->weeklyPlan->week_number); ?>: <?php echo e($evaluation->weeklyPlan->title); ?></span>
                    <span class="week-score"><?php echo e($evaluation->total_score); ?> / <?php echo e($evaluation->max_score); ?></span>
                </div>

                <?php $__currentLoopData = $evaluation->itemScores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $itemScore): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="item-row">
                        <span><?php echo e($itemScore->weeklyPlanEvaluationItem->evaluationItem->name); ?></span>
                        <span><?php echo e($itemScore->score ?? '—'); ?> / <?php echo e($itemScore->weeklyPlanEvaluationItem->max_score); ?></span>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <?php if($evaluation->weeklyPlan->video || $evaluation->weeklyPlan->homework): ?>
                    <div class="resource-links">
                        <?php if($evaluation->weeklyPlan->video?->video_url): ?>
                            <a href="<?php echo e($evaluation->weeklyPlan->video->video_url); ?>" target="_blank">🎬 مشاهدة فيديو الأسبوع</a>
                        <?php endif; ?>
                        <?php if($evaluation->weeklyPlan->homework): ?>
                            <a href="#" onclick="alert('<?php echo e(addslashes($evaluation->weeklyPlan->homework->instructions ?? $evaluation->weeklyPlan->homework->title)); ?>'); return false;">📝 عرض الواجب</a>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <p class="empty">لا توجد تقييمات معتمدة بعد لهذا الأسبوع.</p>
        <?php endif; ?>
    </div>
</body>
</html><?php /**PATH D:\work\Laravel\AslohaThabet\resources\views/portal/student.blade.php ENDPATH**/ ?>