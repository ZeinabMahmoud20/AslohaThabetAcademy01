

<?php $__env->startSection('title', 'إنشاء خطة أسبوعية'); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-header">
        <h1>إنشاء خطة أسبوعية جديدة</h1>
        <a href="<?php echo e(route('weekly-plans.index', ['level_id' => $levelId])); ?>" class="btn btn-outline">⟵ رجوع للقائمة</a>
    </div>

    <div class="card" style="max-width: 560px;">
        <form method="POST" action="<?php echo e(route('weekly-plans.store')); ?>">
            <?php echo csrf_field(); ?>

            <div class="form-group">
                <label for="level_id">المستوى</label>
                <select name="level_id" id="level_id" required>
                    <?php $__currentLoopData = $levels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $level): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($level->id); ?>" <?php echo e(old('level_id', $levelId) == $level->id ? 'selected' : ''); ?>>
                            <?php echo e($level->name); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <div class="form-group">
                <label for="week_number">رقم الأسبوع</label>
                <input type="number" name="week_number" id="week_number" min="1" required
                       value="<?php echo e(old('week_number', $nextWeekNumber)); ?>">
            </div>

            <div class="form-group">
                <label for="title">عنوان الخطة</label>
                <input type="text" name="title" id="title" required value="<?php echo e(old('title')); ?>"
                       placeholder="مثال: سورة الفاتحة وآداب الاستماع">
            </div>

            <div class="form-group">
                <label for="description">الوصف (اختياري)</label>
                <textarea name="description" id="description" rows="3"><?php echo e(old('description')); ?></textarea>
            </div>

            <div class="row-2" style="display:grid; grid-template-columns:1fr 1fr; gap:12px;">
                <div class="form-group">
                    <label for="start_date">تاريخ البداية (اختياري)</label>
                    <input type="date" name="start_date" id="start_date" value="<?php echo e(old('start_date')); ?>">
                </div>
                <div class="form-group">
                    <label for="end_date">تاريخ النهاية (اختياري)</label>
                    <input type="date" name="end_date" id="end_date" value="<?php echo e(old('end_date')); ?>">
                </div>
            </div>

            <button type="submit" class="btn btn-primary" style="width:100%;">إنشاء الخطة</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.academy', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\work\Laravel\AslohaThabet\resources\views/weekly-plans/create.blade.php ENDPATH**/ ?>