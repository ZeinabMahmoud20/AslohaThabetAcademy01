

<?php $__env->startSection('title', 'إنشاء فصل جديد'); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-header">
        <h1>إنشاء فصل جديد</h1>
        <a href="<?php echo e(route('classes.index')); ?>" class="btn btn-outline">⟵ رجوع للقائمة</a>
    </div>

    <div class="card" style="max-width: 480px;">
        <form method="POST" action="<?php echo e(route('classes.store')); ?>">
            <?php echo csrf_field(); ?>

            <div class="form-group">
                <label for="level_id">المستوى</label>
                <select name="level_id" id="level_id" required>
                    <option value="" disabled selected>اختر المستوى</option>
                    <?php $__currentLoopData = $levels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $level): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($level->id); ?>" <?php echo e(old('level_id') == $level->id ? 'selected' : ''); ?>>
                            <?php echo e($level->name); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <div class="form-group">
                <label for="name">اسم الفصل</label>
                <input type="text" name="name" id="name" required value="<?php echo e(old('name')); ?>" placeholder="مثال: فصل أ">
            </div>

            <button type="submit" class="btn btn-primary" style="width:100%;">إنشاء الفصل</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.academy', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\work\Laravel\AslohaThabet\resources\views/classes/create.blade.php ENDPATH**/ ?>