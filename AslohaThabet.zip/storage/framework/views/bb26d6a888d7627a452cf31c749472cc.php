

<?php $__env->startSection('title', 'إدارة الامتحان — ' . $exam->title); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-header">
        <h1><?php echo e($exam->title); ?></h1>
        <a href="<?php echo e(route('exams.index', ['level_id' => $exam->level_id])); ?>" class="btn btn-outline">⟵ رجوع للقائمة</a>
    </div>

    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update', $exam)): ?>
        <?php if($exam->status === 'draft'): ?>
            <div class="alert alert-error" style="display:flex; align-items:center; justify-content:space-between;">
                <span>هذا الامتحان لا يزال مسودة ولن يظهر للطلاب حتى يتم نشره.</span>
                <form method="POST" action="<?php echo e(route('exams.publish', $exam)); ?>">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PATCH'); ?>
                    <button type="submit" class="btn btn-gold">نشر الامتحان الآن</button>
                </form>
            </div>
        <?php else: ?>
            <div class="alert alert-success" style="display:flex; align-items:center; justify-content:space-between;">
                <span>
                    هذا الامتحان منشور. الدرجة الكلية: <?php echo e($exam->max_score); ?> —
                    متاح من <?php echo e($exam->start_at->format('Y-m-d H:i')); ?> إلى <?php echo e($exam->end_at->format('Y-m-d H:i')); ?>.
                </span>
                <?php if($exam->attempts()->count() === 0): ?>
                    <form method="POST" action="<?php echo e(route('exams.unpublish', $exam)); ?>">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PATCH'); ?>
                        <button type="submit" class="btn btn-outline">إلغاء النشر للتعديل</button>
                    </form>
                <?php endif; ?>
            </div>
        <?php endif; ?>
    <?php else: ?>
        <?php if($exam->status === 'published'): ?>
            <div class="alert alert-success">
                هذا الامتحان منشور. الدرجة الكلية: <?php echo e($exam->max_score); ?> —
                متاح من <?php echo e($exam->start_at->format('Y-m-d H:i')); ?> إلى <?php echo e($exam->end_at->format('Y-m-d H:i')); ?>.
            </div>
        <?php else: ?>
            <div class="alert alert-error">هذا الامتحان لا يزال مسودة.</div>
        <?php endif; ?>
    <?php endif; ?>

    
    <div class="card" style="margin-bottom: 20px;">
        <h3 style="color: var(--color-green-dark); margin-top:0;">الأسئلة (<?php echo e($exam->questions->count()); ?>)</h3>

        <?php $__empty_1 = true; $__currentLoopData = $exam->questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div style="border: 1px solid var(--color-border); border-radius: 10px; padding: 14px 16px; margin-bottom: 12px;">
                <div style="display:flex; align-items:flex-start; justify-content:space-between;">
                    <div>
                        <strong><?php echo e($question->display_order); ?>. <?php echo e($question->question_text); ?></strong>
                        <div style="font-size: 12px; color: var(--color-muted); margin-top: 2px;">
                            <?php echo e($question->score); ?> درجة — <?php echo e($question->question_type === 'true_false' ? 'صح/خطأ' : 'اختيار من متعدد'); ?>

                        </div>
                    </div>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update', $exam)): ?>
                        <?php if($exam->status === 'draft'): ?>
                            <form method="POST" action="<?php echo e(route('exams.questions.remove', [$exam, $question])); ?>">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-danger" style="padding: 4px 10px; font-size:12px;">حذف</button>
                            </form>
                        <?php endif; ?>
                    <?php endif; ?>
                </div>
                <ul style="margin: 10px 0 0; padding-right: 20px; font-size: 13px;">
                    <?php $__currentLoopData = $question->options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li style="<?php echo e($option->is_correct ? 'color: var(--color-green-dark); font-weight:700;' : ''); ?>">
                            <?php echo e($option->option_text); ?> <?php echo e($option->is_correct ? '✅' : ''); ?>

                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <p style="color: var(--color-muted); text-align:center; padding: 20px;">لم تتم إضافة أسئلة بعد.</p>
        <?php endif; ?>
    </div>

    
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update', $exam)): ?>
        <?php if($exam->status === 'draft'): ?>
            <div class="card">
                <h3 style="color: var(--color-green-dark); margin-top:0;">إضافة سؤال جديد</h3>

                <form method="POST" action="<?php echo e(route('exams.questions.add', $exam)); ?>">
                    <?php echo csrf_field(); ?>

                    <div class="form-group">
                        <label for="question_text">نص السؤال</label>
                        <textarea name="question_text" id="question_text" rows="2" required><?php echo e(old('question_text')); ?></textarea>
                    </div>

                    <div style="display:grid; grid-template-columns:1fr 1fr; gap:12px;">
                        <div class="form-group">
                            <label for="question_type">نوع السؤال</label>
                            <select name="question_type" id="question_type" onchange="toggleOptionType(this.value)">
                                <option value="multiple_choice">اختيار من متعدد</option>
                                <option value="true_false">صح / خطأ</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="score">الدرجة</label>
                            <input type="number" step="0.01" min="0.01" name="score" id="score" required value="<?php echo e(old('score', 5)); ?>">
                        </div>
                    </div>

                    <label style="display:block; font-weight:700; font-size:13px; margin-bottom:8px; color: var(--color-green-dark);">
                        حدد الإجابة الصحيحة
                    </label>

                    
                    <div id="mc_options">
                        <?php for($i = 0; $i < 4; $i++): ?>
                            <div style="display:flex; align-items:center; gap:10px; margin-bottom: 8px;">
                                <input type="radio" name="correct_option" value="<?php echo e($i); ?>" <?php echo e($i === 0 ? 'checked' : ''); ?>>
                                <input type="text" name="options[<?php echo e($i); ?>][option_text]" placeholder="الخيار <?php echo e($i + 1); ?>"
                                       style="flex:1; padding: 8px 10px; border-radius:8px; border:1.5px solid var(--color-border);"
                                       <?php echo e($i < 2 ? 'required' : ''); ?>>
                            </div>
                        <?php endfor; ?>
                    </div>

                    
                    <div id="tf_options" style="display:none;">
                        <div style="display:flex; align-items:center; gap:10px; margin-bottom: 8px;">
                            <input type="radio" name="correct_option" value="0" disabled>
                            <input type="hidden" name="options[0][option_text]" value="صح" disabled>
                            <span style="flex:1; padding: 8px 10px;">صح</span>
                        </div>
                        <div style="display:flex; align-items:center; gap:10px; margin-bottom: 8px;">
                            <input type="radio" name="correct_option" value="1" disabled>
                            <input type="hidden" name="options[1][option_text]" value="خطأ" disabled>
                            <span style="flex:1; padding: 8px 10px;">خطأ</span>
                        </div>
                    </div>

                    <button type="submit" class="btn btn-primary" style="margin-top: 10px;">إضافة السؤال</button>
                </form>
            </div>

            <script>
                function toggleOptionType(type) {
                    const mc = document.getElementById('mc_options');
                    const tf = document.getElementById('tf_options');

                    const setEnabled = (container, enabled) => {
                        container.querySelectorAll('input').forEach(input => {
                            input.disabled = !enabled;
                        });
                    };

                    if (type === 'true_false') {
                        mc.style.display = 'none';
                        tf.style.display = 'block';
                        setEnabled(mc, false);
                        setEnabled(tf, true);
                    } else {
                        mc.style.display = 'block';
                        tf.style.display = 'none';
                        setEnabled(mc, true);
                        setEnabled(tf, false);
                    }
                }
            </script>
        <?php endif; ?>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.academy', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\work\Laravel\AslohaThabet\resources\views/exams/show.blade.php ENDPATH**/ ?>