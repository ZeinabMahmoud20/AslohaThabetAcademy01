

<?php $__env->startSection('title', 'تعيين الطلاب للفصول'); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-header">
        <h1>تعيين الطلاب للفصول</h1>
    </div>

    <div class="card" style="margin-bottom: 18px; display:flex; gap:10px; flex-wrap: wrap;">
        <a href="<?php echo e(route('students.index')); ?>"
           class="btn <?php echo e(! request('status') ? 'btn-gold' : 'btn-outline'); ?>">الكل</a>
        <a href="<?php echo e(route('students.index', ['status' => 'unassigned'])); ?>"
           class="btn <?php echo e(request('status') === 'unassigned' ? 'btn-gold' : 'btn-outline'); ?>">بدون فصل</a>
        <a href="<?php echo e(route('students.index', ['status' => 'assigned'])); ?>"
           class="btn <?php echo e(request('status') === 'assigned' ? 'btn-gold' : 'btn-outline'); ?>">معيّن/ة بالفعل</a>

        <span style="width:1px; background: var(--color-border); margin: 0 6px;"></span>

        <a href="<?php echo e(route('students.index', request()->except('level_id'))); ?>"
           class="btn <?php echo e(! request('level_id') ? 'btn-gold' : 'btn-outline'); ?>">كل المستويات</a>
        <?php $__currentLoopData = $levels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $level): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a href="<?php echo e(route('students.index', array_merge(request()->except('level_id'), ['level_id' => $level->id]))); ?>"
               class="btn <?php echo e(request('level_id') == $level->id ? 'btn-gold' : 'btn-outline'); ?>"><?php echo e($level->name); ?></a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <div class="card">
        <table>
            <thead>
                <tr>
                    <th>الطالب/ة</th>
                    <th>المستوى</th>
                    <th>الفصل الحالي</th>
                    <th>تعيين / تبديل فصل</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $attempts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attempt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($attempt->student->full_name); ?></td>
                        <td><?php echo e($attempt->level->name); ?></td>
                        <td>
                            <?php if($attempt->activeClassAssignment): ?>
                                <span class="badge-status badge-accepted">
                                    <?php echo e($attempt->activeClassAssignment->classRoom->name); ?>

                                </span>
                            <?php else: ?>
                                <span class="badge-status badge-pending">بدون فصل</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <form method="POST" action="<?php echo e(route('students.assign-class', $attempt)); ?>"
                                  style="display:flex; gap:8px;">
                                <?php echo csrf_field(); ?>
                                <select name="class_id" required style="width: auto; min-width: 160px;">
                                    <option value="" disabled selected>اختر فصل</option>
                                    <?php $__currentLoopData = $classesByLevel->get($attempt->level_id, collect()); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $class): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($class->id); ?>"><?php echo e($class->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <button type="submit" class="btn btn-primary">
                                    <?php echo e($attempt->activeClassAssignment ? 'تبديل' : 'تعيين'); ?>

                                </button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="4" style="text-align:center; color: var(--color-muted); padding: 30px;">
                            لا يوجد طلاب مطابقون.
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <div style="margin-top: 18px;">
        <?php echo e($attempts->links()); ?>

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.academy', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\work\Laravel\AslohaThabet\resources\views/students/index.blade.php ENDPATH**/ ?>