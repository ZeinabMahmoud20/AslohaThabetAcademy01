

<?php $__env->startSection('title', 'الخطط الأسبوعية'); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-header">
    <h1>الخطط الأسبوعية</h1>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create', \App\Models\WeeklyPlan::class)): ?>
        <a href="<?php echo e(route('weekly-plans.create', ['level_id' => $levelId])); ?>" class="btn btn-primary">+ خطة أسبوعية جديدة</a>
    <?php endif; ?>
</div>

    <div class="card" style="margin-bottom: 18px; display:flex; gap:10px; flex-wrap: wrap;">
        <?php $__currentLoopData = $levels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $level): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a href="<?php echo e(route('weekly-plans.index', ['level_id' => $level->id])); ?>"
               class="btn <?php echo e($levelId == $level->id ? 'btn-gold' : 'btn-outline'); ?>"><?php echo e($level->name); ?></a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <div class="card">
        <table>
            <thead>
                <tr>
                    <th>الأسبوع</th>
                    <th>العنوان</th>
                    <th>الفيديو</th>
                    <th>الواجب</th>
                    <th>عناصر التقييم</th>
                    <th>الحالة</th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $plans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($plan->week_number); ?></td>
                        <td><?php echo e($plan->title); ?></td>
                        <td><?php echo e($plan->video ? '✅' : '—'); ?></td>
                        <td><?php echo e($plan->homework ? '✅' : '—'); ?></td>
                        <td><?php echo e($plan->evaluation_items_count); ?> عنصر</td>
                        <td>
                            <?php
                                $statusMap = [
                                    'draft' => ['مسودة', 'badge-pending'],
                                    'published' => ['منشورة', 'badge-accepted'],
                                    'closed' => ['مغلقة', 'badge-rejected'],
                                ];
                                [$label, $class] = $statusMap[$plan->status] ?? [$plan->status, 'badge-pending'];
                            ?>
                            <span class="badge-status <?php echo e($class); ?>"><?php echo e($label); ?></span>
                        </td>
                        <td>
                            <a href="<?php echo e(route('weekly-plans.show', $plan)); ?>" class="btn btn-outline">إدارة</a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="7" style="text-align:center; color: var(--color-muted); padding: 30px;">
                            لا توجد خطط أسبوعية لهذا المستوى بعد.
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.academy', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\work\Laravel\AslohaThabet\resources\views/weekly-plans/index.blade.php ENDPATH**/ ?>