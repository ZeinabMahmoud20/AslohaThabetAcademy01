

<?php $__env->startSection('title', 'تصحيح الأسبوع ' . $weeklyPlan->week_number . ' — ' . $class->name); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-header">
        <h1><?php echo e($class->name); ?> — الأسبوع <?php echo e($weeklyPlan->week_number); ?>: <?php echo e($weeklyPlan->title); ?></h1>
        <a href="<?php echo e(route('weekly-evaluations.index')); ?>" class="btn btn-outline">⟵ رجوع لاختيار فصل آخر</a>
    </div>

    
    <div class="card" style="margin-bottom: 18px;">
        <h3 style="color: var(--color-green-dark); margin-top:0;">حالة اعتماد كل طالب/ة</h3>
        <table>
            <thead>
                <tr>
                    <th>الطالب/ة</th>
                    <th>الدرجة الحالية</th>
                    <th>الحالة</th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $evaluations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $evaluation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($evaluation->levelAttempt->student->full_name); ?></td>
                        <td><?php echo e($evaluation->total_score); ?> / <?php echo e($evaluation->max_score); ?></td>
                        <td>
                            <?php
                                $statusMap = [
                                    'draft' => ['مسودة', 'badge-pending'],
                                    'approved' => ['معتمد', 'badge-accepted'],
                                    'reopened' => ['أعيد فتحه', 'badge-pending'],
                                ];
                                [$label, $class_] = $statusMap[$evaluation->status] ?? [$evaluation->status, 'badge-pending'];
                            ?>
                            <span class="badge-status <?php echo e($class_); ?>"><?php echo e($label); ?></span>
                        </td>
                        <td>
                            <?php if($evaluation->status !== 'approved'): ?>
                                <form method="POST" action="<?php echo e(route('weekly-evaluations.approve', $evaluation)); ?>">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('PATCH'); ?>
                                    <button type="submit" class="btn btn-primary" style="padding:5px 12px; font-size:12px;">اعتماد</button>
                                </form>
                            <?php else: ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('reopen', $evaluation)): ?>
                                <form method="POST" action="<?php echo e(route('weekly-evaluations.reopen', $evaluation)); ?>">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('PATCH'); ?>
                                    <button type="submit" class="btn btn-outline" style="padding:5px 12px; font-size:12px;">إعادة فتح</button>
                                </form>
                            <?php endif; ?>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>

    
    <div class="card">
        <h3 style="color: var(--color-green-dark); margin-top:0;">جدول الدرجات</h3>
        <form method="POST" action="<?php echo e(route('weekly-evaluations.save-scores')); ?>">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="class_id" value="<?php echo e($class->id); ?>">
            <input type="hidden" name="weekly_plan_id" value="<?php echo e($weeklyPlan->id); ?>">

            <div style="overflow-x: auto;">
                <table>
                    <thead>
                        <tr>
                            <th>الطالب/ة</th>
                            <?php $__currentLoopData = $weeklyPlan->evaluationItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $planItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <th>
                                    <?php echo e($planItem->evaluationItem->name); ?>

                                    <br><small style="font-weight: 400;">من <?php echo e($planItem->max_score); ?></small>
                                </th>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $evaluations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $evaluation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $scoresByItem = $evaluation->itemScores->keyBy('weekly_plan_evaluation_item_id');
                                $isLocked = $evaluation->status === 'approved';
                            ?>
                            <tr>
                                <td><?php echo e($evaluation->levelAttempt->student->full_name); ?></td>
                                <?php $__currentLoopData = $weeklyPlan->evaluationItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $planItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <td>
                                        <input
                                            type="number"
                                            step="0.01"
                                            min="0"
                                            max="<?php echo e($planItem->max_score); ?>"
                                            name="scores[<?php echo e($evaluation->level_attempt_id); ?>][<?php echo e($planItem->id); ?>]"
                                            value="<?php echo e($scoresByItem->get($planItem->id)?->score); ?>"
                                            style="width: 80px; padding: 6px;"
                                            <?php echo e($isLocked ? 'disabled' : ''); ?>

                                        >
                                    </td>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>

            <button type="submit" class="btn btn-primary" style="margin-top: 16px;">💾 حفظ الدرجات</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.academy', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\work\Laravel\AslohaThabet\resources\views/weekly-evaluations/grade.blade.php ENDPATH**/ ?>