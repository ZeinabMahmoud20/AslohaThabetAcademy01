

<?php $__env->startSection('title', 'النتائج النهائية'); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-header">
        <h1>النتائج النهائية</h1>
    </div>

    <div class="card" style="margin-bottom: 18px; display:flex; gap:10px; flex-wrap: wrap;">
        <?php $__currentLoopData = $levels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $level): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a href="<?php echo e(route('final-results.index', ['level_id' => $level->id])); ?>"
               class="btn <?php echo e($levelId == $level->id ? 'btn-gold' : 'btn-outline'); ?>"><?php echo e($level->name); ?></a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <div class="card">
        <table>
            <thead>
                <tr>
                    <th>الطالب/ة</th>
                    <th>الفصل</th>
                    <th>الدرجة النهائية</th>
                    <th>الحالة</th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $attempts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attempt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($attempt->student->full_name); ?></td>
                        <td><?php echo e($attempt->activeClassAssignment?->classRoom?->name ?? '—'); ?></td>
                        <td>
                            <?php if($attempt->finalResult): ?>
                                <?php echo e($attempt->finalResult->final_score); ?> / 100
                            <?php else: ?>
                                <span style="color: var(--color-muted);">لم يتم الحساب بعد</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if($attempt->finalResult): ?>
                                <?php
                                    $statusMap = [
                                        'calculated' => ['محسوبة', 'badge-pending'],
                                        'teacher_approved' => ['موافقة المعلم/ة', 'badge-pending'],
                                        'admin_approved' => ['موافقة الإدارة', 'badge-accepted'],
                                        'final' => ['نهائية', 'badge-accepted'],
                                    ];
                                    [$label, $class] = $statusMap[$attempt->finalResult->status] ?? [$attempt->finalResult->status, 'badge-pending'];
                                ?>
                                <span class="badge-status <?php echo e($class); ?>"><?php echo e($label); ?></span>
                            <?php else: ?>
                                <span class="badge-status badge-pending">—</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if($attempt->finalResult): ?>
                                <a href="<?php echo e(route('final-results.show', $attempt->finalResult)); ?>" class="btn btn-outline">عرض</a>
                            <?php else: ?>
                                <form method="POST" action="<?php echo e(route('final-results.calculate', $attempt)); ?>">
                                    <?php echo csrf_field(); ?>
                                    <button type="submit" class="btn btn-primary">حساب النتيجة</button>
                                </form>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="5" style="text-align:center; color: var(--color-muted); padding: 30px;">
                            لا يوجد طلاب نشطون في هذا المستوى.
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.academy', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\work\Laravel\AslohaThabet\resources\views/final-results/index.blade.php ENDPATH**/ ?>