

<?php $__env->startSection('title', 'الفصول'); ?>

<?php $__env->startSection('content'); ?>
<div class="page-header">
    <h1>الفصول</h1>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create', \App\Models\ClassRoom::class)): ?>
        <a href="<?php echo e(route('classes.create')); ?>" class="btn btn-primary">+ إنشاء فصل جديد</a>
    <?php endif; ?>
</div>

    <div class="card" style="margin-bottom: 18px; display:flex; gap:10px; flex-wrap: wrap;">
        <a href="<?php echo e(route('classes.index')); ?>"
           class="btn <?php echo e(! request('level_id') ? 'btn-gold' : 'btn-outline'); ?>">كل المستويات</a>
        <?php $__currentLoopData = $levels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $level): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a href="<?php echo e(route('classes.index', ['level_id' => $level->id])); ?>"
               class="btn <?php echo e(request('level_id') == $level->id ? 'btn-gold' : 'btn-outline'); ?>"><?php echo e($level->name); ?></a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <div class="card">
        <table>
            <thead>
                <tr>
                    <th>اسم الفصل</th>
                    <th>المستوى</th>
                    <th>المعلم/ة الحالي/ة</th>
                    <th>المشرفون النشطون</th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $class): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($class->name); ?></td>
                        <td><?php echo e($class->level->name); ?></td>
                        <td>
                            <?php if($class->activeTeacherAssignment): ?>
                                <?php echo e($class->activeTeacherAssignment->teacher->full_name); ?>

                            <?php else: ?>
                                <span class="badge-status badge-pending">لا يوجد معلم/ة</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php $__empty_2 = true; $__currentLoopData = $class->activeSupervisorAssignments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
                                <span class="badge-status badge-accepted"><?php echo e($sa->supervisor->full_name); ?></span>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                                <span style="color: var(--color-muted);">—</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <a href="<?php echo e(route('classes.show', $class)); ?>" class="btn btn-outline">إدارة الفصل</a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="5" style="text-align:center; color: var(--color-muted); padding: 30px;">
                            لا توجد فصول مطابقة.
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.academy', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\work\Laravel\AslohaThabet\resources\views/classes/index.blade.php ENDPATH**/ ?>