<?php $__env->startSection('title', 'مراجعة طلب — ' . $application->student_full_name); ?>

<?php $__env->startSection('content'); ?>
<div class="page-header">
    <h1>مراجعة طلب: <?php echo e($application->student_full_name); ?></h1>
    <a href="<?php echo e(route('applications.index')); ?>" class="btn btn-outline">⟵ رجوع للقائمة</a>
</div>

<div style="display: grid; grid-template-columns: 2fr 1fr; gap: 20px;">

    
    <div class="card">
        <h3 style="color: var(--color-green-dark); margin-top:0;">بيانات الطالب</h3>
        <table>
            <tr>
                <td style="width:180px; font-weight:700;">الاسم الكامل</td>
                <td><?php echo e($application->student_full_name); ?></td>
            </tr>
            <tr>
                <td style="font-weight:700;">تاريخ الميلاد</td>
                <td><?php echo e($application->student_dob->format('Y-m-d')); ?></td>
            </tr>
            <tr>
                <td style="font-weight:700;">العمر عند التقديم</td>
                <td><?php echo e($application->computed_age_years); ?> سنة</td>
            </tr>
            <tr>
                <td style="font-weight:700;">الدولة / المحافظة</td>
                <td><?php echo e($application->country); ?> — <?php echo e($application->governorate); ?></td>
            </tr>
            <tr>
                <td style="font-weight:700;">المدرسة / الصف</td>
                <td><?php echo e($application->school); ?> — <?php echo e($application->grade_level); ?></td>
            </tr>
            <tr>
                <td style="font-weight:700;">تاريخ التقديم</td>
                <td><?php echo e($application->submitted_at->format('Y-m-d H:i')); ?></td>
            </tr>
        </table>

        <h3 style="color: var(--color-green-dark);">بيانات ولي الأمر</h3>
        <table>
            <tr>
                <td style="width:180px; font-weight:700;">الاسم</td>
                <td><?php echo e($application->guardian->full_name); ?></td>
            </tr>
            <tr>
                <td style="font-weight:700;">رقم الهاتف</td>
                <td dir="ltr" style="text-align:right;"><?php echo e($application->guardian->phone_number); ?></td>
            </tr>
            <tr>
                <td style="font-weight:700;">صلة القرابة</td>
                <td><?php echo e($application->guardian->relationship_to_student); ?></td>
            </tr>
        </table>

        <?php if($application->is_age_exception): ?>
        <div class="alert alert-error" style="margin-top: 16px;">
            ⚠️ هذا الطلب يمثل استثناءً في السن (خارج نطاق 7–10 سنوات) —
            <?php if($application->exception_approved_at): ?>
            تمت الموافقة على الاستثناء بتاريخ <?php echo e($application->exception_approved_at->format('Y-m-d')); ?>.
            <?php else: ?>
            <strong>لم تتم الموافقة على الاستثناء بعد.</strong> يجب اعتماده قبل قبول الطلب (BR-002).
            <?php endif; ?>
        </div>
        <?php endif; ?>
    </div>

    
    <div class="card">
        <h3 style="color: var(--color-green-dark); margin-top:0;">إجراء المراجعة</h3>

        <?php if($application->status === 'pending_review' || $application->status === 'admin_review'): ?>

        <?php if($application->is_age_exception && ! $application->exception_approved_at): ?>
        <form method="POST" action="<?php echo e(route('applications.approve-exception', $application)); ?>" style="margin-bottom: 20px;">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PATCH'); ?> <?php echo csrf_field(); ?>
            <button type="submit" class="btn btn-gold" style="width:100%;">
                اعتماد استثناء السن
            </button>
        </form>
        <?php endif; ?>

        <form method="POST" action="<?php echo e(route('applications.accept', $application)); ?>" style="margin-bottom: 14px;">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PATCH'); ?>
            <div class="form-group">
                <label for="initial_level_id">المستوى المبدئي</label>
                <select name="initial_level_id" id="initial_level_id" required>
                    <?php $__currentLoopData = $levels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $level): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($level->id); ?>"><?php echo e($level->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <button type="submit" class="btn btn-primary" style="width:100%;"
                <?php echo e($application->is_age_exception && ! $application->exception_approved_at ? 'disabled' : ''); ?>>
                ✅ قبول الطلب
            </button>
        </form>

        <hr style="border: none; border-top: 1px solid var(--color-border); margin: 18px 0;">

        <form method="POST" action="<?php echo e(route('applications.reject', $application)); ?>">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PATCH'); ?>
            <div class="form-group">
                <label for="rejection_reason">سبب الرفض</label>
                <textarea name="rejection_reason" id="rejection_reason" rows="3" required></textarea>
            </div>
            <button type="submit" class="btn btn-danger" style="width:100%;">❌ رفض الطلب</button>
        </form>

        <?php elseif($application->status === 'accepted'): ?>
        <div class="alert alert-success">
            تم القبول بتاريخ <?php echo e($application->reviewed_at->format('Y-m-d')); ?>

            <?php if($application->student): ?>
            <br>كود الطالب: <strong><?php echo e($application->student->academy_student_code ?? '—'); ?></strong>
            <?php endif; ?>
        </div>

        <div class="card" style="margin-top: 16px; background: #fbfaf3;">
            <h3 style="color: var(--color-green-dark); margin-top:0; font-size: 15px;">
                🔑 دخول ولي الأمر لبوابة المتابعة
            </h3>

            <table style="margin-bottom: 14px;">
                <tr>
                    <td style="width:140px; font-weight:700;">رقم هاتف الدخول</td>
                    <td dir="ltr" style="text-align:right;"><?php echo e($application->guardian->phone_number); ?></td>
                </tr>
                <tr>
                    <td style="font-weight:700;">كود الدخول الحالي</td>
                    <td>
                        <?php if($application->guardian->access_code): ?>
                        <span style="font-family: monospace; font-size: 18px; font-weight:800; color: var(--color-green-dark); letter-spacing: 2px;">
                            <?php echo e($application->guardian->access_code); ?>

                        </span>
                        <span style="color: var(--color-muted); font-size: 12px;">
                            (تم توليده بتاريخ <?php echo e($application->guardian->access_code_generated_at?->format('Y-m-d')); ?>)
                        </span>
                        <?php else: ?>
                        <span style="color: var(--color-muted);">لم يتم توليد كود بعد</span>
                        <?php endif; ?>
                    </td>
                </tr>
            </table>

            <form method="POST" action="<?php echo e(route('applications.generate-guardian-code', $application)); ?>">
                <?php echo csrf_field(); ?>
                <button type="submit" class="btn btn-gold">
                    <?php echo e($application->guardian->access_code ? '🔄 توليد كود جديد' : '➕ توليد كود دخول'); ?>

                </button>
            </form>
        </div>
        <?php else: ?>
        <div class="alert alert-error">
            تم الرفض بتاريخ <?php echo e($application->reviewed_at->format('Y-m-d')); ?><br>
            السبب: <?php echo e($application->rejection_reason); ?>

        </div>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.academy', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\work\Laravel\AslohaThabet\resources\views/applications/show.blade.php ENDPATH**/ ?>