

<?php $__env->startSection('title', 'إدارة المعلمين والمشرفين'); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-header">
        <h1><?php echo e($role === 'supervisor' ? 'المشرفات' : ($role === 'all' ? 'كل المعلمين والمشرفين' : 'المعلمات')); ?></h1>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create', \App\Models\User::class)): ?>
        <a href="<?php echo e(route('staff.create', ['role' => $role === 'supervisor' ? 'supervisor' : 'teacher'])); ?>" class="btn btn-primary">
            + إضافة <?php echo e($role === 'supervisor' ? 'مشرف/ة' : 'معلم/ة'); ?>

        </a>
        <?php endif; ?>
    </div>

    <div class="card" style="margin-bottom: 18px; display:flex; gap:10px;">
        <a href="<?php echo e(route('staff.index', ['role' => 'teacher'])); ?>"
           class="btn <?php echo e($role === 'teacher' ? 'btn-gold' : 'btn-outline'); ?>">المعلمات</a>
        <a href="<?php echo e(route('staff.index', ['role' => 'supervisor'])); ?>"
           class="btn <?php echo e($role === 'supervisor' ? 'btn-gold' : 'btn-outline'); ?>">المشرفات</a>
        <a href="<?php echo e(route('staff.index', ['role' => 'all'])); ?>"
           class="btn <?php echo e($role === 'all' ? 'btn-gold' : 'btn-outline'); ?>">الكل</a>
    </div>

    <div class="card">
        <table>
            <thead>
                <tr>
                    <th>الاسم</th>
                    <th>البريد الإلكتروني</th>
                    <th>الهاتف</th>
                    <th>الدور</th>
                    <th>الحالة</th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $staff; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($member->full_name); ?></td>
                        <td dir="ltr" style="text-align:right;"><?php echo e($member->email); ?></td>
                        <td dir="ltr" style="text-align:right;"><?php echo e($member->phone_number ?? '—'); ?></td>
                        <td><?php echo e($member->role_type === 'teacher' ? 'معلم/ة' : 'مشرف/ة'); ?></td>
                        <td>
                            <span class="badge-status <?php echo e($member->is_active ? 'badge-accepted' : 'badge-rejected'); ?>">
                                <?php echo e($member->is_active ? 'نشط' : 'موقوف'); ?>

                            </span>
                        </td>
                        <td>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update', $member)): ?>
                            <form method="POST" action="<?php echo e(route('staff.toggle-active', $member)); ?>">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PATCH'); ?>
                                <button type="submit" class="btn btn-outline">
                                    <?php echo e($member->is_active ? 'إيقاف' : 'تفعيل'); ?>

                                </button>
                            </form>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="6" style="text-align:center; color: var(--color-muted); padding: 30px;">
                            لا يوجد أعضاء مطابقين.
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <div style="margin-top: 18px;">
        <?php echo e($staff->links()); ?>

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.academy', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\work\Laravel\AslohaThabet\resources\views/staff/index.blade.php ENDPATH**/ ?>