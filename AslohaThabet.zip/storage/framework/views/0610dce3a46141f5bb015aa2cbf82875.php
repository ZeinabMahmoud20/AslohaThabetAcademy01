

<?php $__env->startSection('title', 'لوحة المعلومات'); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-header">
        <h1>مرحباً، <?php echo e(auth()->user()->full_name); ?> 👋</h1>
    </div>

    <?php if($pendingApprovals->isNotEmpty()): ?>
        <div class="alert alert-error" style="display:flex; align-items:center; justify-content:space-between;">
            <span>لديك <?php echo e($pendingApprovals->count()); ?> نتيجة نهائية بانتظار موافقتك.</span>
            <a href="<?php echo e(route('final-results.index')); ?>" class="btn btn-gold">مراجعة الآن</a>
        </div>
    <?php endif; ?>

    <h3 style="color: var(--color-green-dark); margin-bottom: 14px;">فصولك النشطة</h3>

    <?php $__empty_1 = true; $__currentLoopData = $classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $class): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="card" style="margin-bottom: 14px; display:flex; align-items:center; justify-content:space-between;">
            <div>
                <strong style="color: var(--color-green-dark); font-size: 16px;"><?php echo e($class->name); ?></strong>
                <span style="color: var(--color-muted); font-size: 13px;"> — <?php echo e($class->level->name); ?></span>
                <div style="font-size: 13px; color: var(--color-muted); margin-top: 4px;">
                    👦 <?php echo e($class->active_students_count); ?> طالب/ة
                </div>
            </div>

            <div style="display:flex; gap:8px;">
                <a href="<?php echo e(route('classes.show', $class)); ?>" class="btn btn-outline">تفاصيل الفصل</a>

                <?php if($class->latestPublishedPlan): ?>
                    <a href="<?php echo e(route('weekly-evaluations.grade', ['class_id' => $class->id, 'weekly_plan_id' => $class->latestPublishedPlan->id])); ?>"
                       class="btn btn-primary">
                        صحّح الأسبوع <?php echo e($class->latestPublishedPlan->week_number); ?>

                    </a>
                <?php endif; ?>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <div class="card" style="text-align:center; color: var(--color-muted); padding: 40px;">
            لا توجد فصول معيّنة عليك حالياً.
        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.academy', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\work\Laravel\AslohaThabet\resources\views/dashboard-teacher.blade.php ENDPATH**/ ?>